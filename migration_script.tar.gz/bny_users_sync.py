import datetime

import psycopg2

import constants
from keycloak import keycloak

# run port forward:
# k port-forward runai-backend-postgresql-0 32451:5432
# and run this file


db_connection = psycopg2.connect(user="user",
                                 password="password",
                                 host="127.0.0.1",
                                 # port="32451",
                                 port="5432",
                                 database="backend")
# keycloak_domain = 'https://cs-bny.runailabs.net/auth/'
# keycloak_domain = 'https://dev-erez0.eastus.cloudapp.azure.com/auth/'
keycloak_domain = 'https://rke-bny.runailabs.com/auth/'
realm_name = "runai"
admin_password = "admin"
constants.current_ssl_verify = False


def sync_bny_users(_):
    runai_user_ids = get_all_users()
    keycloak_users = get_keycloak_user_id_to_email_map()

    print(f'runai user ids: {runai_user_ids}')
    print(f'keycloak users: {keycloak_users}')

    try:
        ids_that_were_duplicated = duplicate_users(runai_user_ids, keycloak_users)
        committed = _commit_changes()
        if committed:
            print(f"total of {len(ids_that_were_duplicated)} users were duplicated")
            print(f"user ids: {ids_that_were_duplicated}")
    except Exception:
        print('rollback all changes...')
        db_connection.rollback()
        raise


def get_all_users():
    with db_connection.cursor() as cursor:
        cursor.execute(f"SELECT user_id from backend.auth_user;")
        users = cursor.fetchall()
    return [user[0] for user in users]


def get_keycloak_user_id_to_email_map():
    kc = keycloak.Keycloak(realm_name, keycloak_domain, admin_password)
    users = kc.get_users()
    return {user['id']: user['email'] for user in users}


def duplicate_users(runai_user_ids, keycloak_users):
    print(f'duplicating {len(runai_user_ids)} users...')
    ids_that_were_duplicated = []
    for runai_user_id in runai_user_ids:
        if runai_user_id not in keycloak_users:
            print(f"runai user {runai_user_id} does not exist in keycloak users, skipping.")
            continue

        user_email = keycloak_users[runai_user_id]
        print(f'duplicating user {runai_user_id} (email={user_email})')
        duplicate_user_with_new_id(runai_user_id, user_email)
        ids_that_were_duplicated.append(runai_user_id)
    return ids_that_were_duplicated


def duplicate_user_with_new_id(current_user_id, new_user_id):
    duplicate_auth_user(current_user_id, new_user_id)
    duplicate_user_roles(current_user_id, new_user_id)
    duplicate_cluster_permissions(current_user_id, new_user_id)
    duplicate_project_permissions(current_user_id, new_user_id)


def duplicate_auth_user(user_id, new_user_id):
    insert_user_query = f""" 
        INSERT INTO backend.auth_user 
        (user_id, tenant_id, all_clusters_permitted, client_id, entity_type) 
         SELECT '{new_user_id}', tenant_id, all_clusters_permitted, client_id, 'sso-user'
         FROM backend.auth_user 
         WHERE user_id='{user_id}'"""

    with db_connection.cursor() as cursor:
        cursor.execute(insert_user_query)


def duplicate_user_roles(user_id, new_user_id):
    insert_roles_query = f""" INSERT INTO backend.roles 
        (user_id, tenant_id, role)  
        SELECT '{new_user_id}', tenant_id, role 
        FROM backend.roles 
        WHERE user_id='{user_id}'"""

    with db_connection.cursor() as cursor:
        cursor.execute(insert_roles_query)


def duplicate_cluster_permissions(user_id, new_user_id):
    insert_cluster_permissions_query = f""" INSERT INTO backend.cluster_permission 
        (user_id, tenant_id, cluster_uuid)  
        SELECT '{new_user_id}', tenant_id, cluster_uuid 
        FROM backend.cluster_permission 
        WHERE user_id='{user_id}'"""

    with db_connection.cursor() as cursor:
        cursor.execute(insert_cluster_permissions_query)


def duplicate_project_permissions(user_id, new_user_id):
    insert_project_permissions_query = f""" INSERT INTO backend.projects_users_permissions 
        (project_id, user_id, tenant_id)  
        SELECT project_id, '{new_user_id}', tenant_id 
        FROM backend.projects_users_permissions 
        WHERE user_id='{user_id}'"""

    with db_connection.cursor() as cursor:
        cursor.execute(insert_project_permissions_query)


def delete_user_with_id(user_id):
    delete_user_auth = f"delete from backend.auth_user where user_id='{user_id}'"
    delete_user_roles = f"delete from backend.roles where user_id='{user_id}'"
    delete_cluster_permission = f"delete from backend.cluster_permission where user_id='{user_id}'"
    delete_project_permission = f"delete from backend.projects_users_permissions where user_id='{user_id}'"

    with db_connection.cursor() as cursor:
        cursor.execute(delete_project_permission)
        cursor.execute(delete_cluster_permission)
        cursor.execute(delete_user_roles)
        cursor.execute(delete_user_auth)

    print(f'deleted user {user_id}')
    committed = _commit_changes()
    if committed:
        print(f'user {user_id} was deleted')


def delete_users(user_ids):
    ids_in_parameter = "'" + "','".join(user_ids) + "'"
    delete_user_auth = f"delete from backend.auth_user where user_id in ({ids_in_parameter})"
    delete_user_roles = f"delete from backend.roles where user_id in ({ids_in_parameter})"
    delete_cluster_permission = f"delete from backend.cluster_permission where user_id in ({ids_in_parameter})"
    delete_project_permission = f"delete from backend.projects_users_permissions where user_id in ({ids_in_parameter})"

    with db_connection.cursor() as cursor:
        cursor.execute(delete_project_permission)
        print(f'deleted_project_permission_count={cursor.rowcount}')

        cursor.execute(delete_cluster_permission)
        print(f'deleted_cluster_permission_count={cursor.rowcount}')

        cursor.execute(delete_user_roles)
        print(f'deleted_roles_count={cursor.rowcount}')

        cursor.execute(delete_user_auth)
        deleted_users_count = cursor.rowcount

    print(f'deleted {deleted_users_count} users')
    if len(user_ids) != deleted_users_count:
        print(f'Notice! got request to delete {len(user_ids)} users, but {deleted_users_count} were deleted.')

    committed = _commit_changes()
    if committed:
        print(f'{deleted_users_count} users were deleted')


def _commit_changes():
    commit = input("Do you want to commit changes? (n/y) -> ")

    if commit.lower() == 'y':
        print('commit changes...')
        db_connection.commit()
        return True
    else:
        print('rollback changes...')
        db_connection.rollback()
        return False


if __name__ == '__main__':
    sync_bny_users(None)
    # delete_user_with_id("test@run.ai")
    #delete_users(["test@run.ai", "eden@hogwarts.com"])
    print('Done.')
