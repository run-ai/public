import os
from enum import Enum


class AuthProvider(Enum):
    keycloak = 'keycloak'
    auth0 = 'auth0'


current_ssl_verify: bool = True
current_domain: str
current_ui_domain: str
current_keycloak_domain: str
