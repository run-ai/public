import json
import requests
import constants


class KeycloakApiClient:

    def __init__(self, base_url: str, user: str, password: str):
        self.url = base_url
        self.realms_path = f'{base_url}admin/realms'
        self.user = user
        self.password = password
        self.realm = 'master'
        self.token = self.get_token()

    def get_token(self) -> str:
        return self._get_token_of("master", {
            'username': self.user,
            'password': self.password,
            'client_id': 'admin-cli',
            'grant_type': 'password'
        })

    def get_token_of_client(self, tenant_name: str, client_id: str, client_secret: str) -> str:
        return self._get_token_of(tenant_name, {
            'grant_type': 'client_credentials',
            'client_id': client_id,
            'client_secret': client_secret,
            'response_type': 'id_token',
            'scope': 'openid'
        })

    def _get_token_of(self, realm, request) -> str:
        tokens_path = f'realms/{realm}/protocol/openid-connect/token'
        response = requests.post(f'{self.url}{tokens_path}', data=request,
                                 headers={'Content-Type': 'application/x-www-form-urlencoded'},
                                 verify=constants.current_ssl_verify)
        if response.status_code != 200:
            print(f'error obtaining keycloak token. status: {response.status_code}, reason: {response.text}')
            exit(1)

        token = response.json()['access_token']
        return token

    def create_realm(self, realm_data):
        return self._post(self.realms_path, realm_data)

    def get_realm(self, realm_name: str):
        return self._get(f'{self.realms_path}/{realm_name}')

    def list_realms(self):
        return self._get(self.realms_path)

    def update_realm(self, realm_name: str, data):
        return self._put(f'{self.realms_path}/{realm_name}', data)

    def delete_realm(self, realm_name: str):
        return self._delete(f'{self.realms_path}/{realm_name}')

    def create_client(self, realm_name: str, client_data: dict):
        return self._post(f'{self.realms_path}/{realm_name}/clients', client_data)

    def update_client(self, realm_name: str, client_data: dict):
        return self._put(f'{self.realms_path}/{realm_name}/clients/{client_data["id"]}', client_data)

    def get_client(self, realm_name: str, client_id: str):
        return self._get(f'{self.realms_path}/{realm_name}/clients?clientId={client_id}')[0]

    def list_clients(self, realm_name: str):
        return self._get(f'{self.realms_path}/{realm_name}/clients')

    def create_client_secret(self, realm_name, client_id):
        return self._post(f'{self.realms_path}/{realm_name}/clients/{client_id}/client-secret')

    def get_client_secret(self, realm_name, client_id):
        return self._get(f'{self.realms_path}/{realm_name}/clients/{client_id}/client-secret')

    def create_protocol_mapper(self, realm_name: str, client_id: str, mapper_data: dict):
        self._post(f'{self.realms_path}/{realm_name}/clients/{client_id}/protocol-mappers/models', mapper_data)

    def list_auth_flows(self, realm_name: str):
        return self._get(f'{self.realms_path}/{realm_name}/authentication/flows')

    def create_auth_flow(self, realm_name: str, auth_flow):
        return self._post(f'{self.realms_path}/{realm_name}/authentication/flows', auth_flow)

    def delete_auth_flow(self, realm_name: str, auth_flow_id):
        return self._delete(f'{self.realms_path}/{realm_name}/authentication/flows/{auth_flow_id}')

    def list_auth_flow_executions(self, realm_name: str, flow_alias: str):
        return self._get(f'{self.realms_path}/{realm_name}/authentication/flows/{flow_alias}/executions')

    def update_auth_flow_exec(self, realm_name: str, flow_alias: str, execution: dict):
        return self._put(f'{self.realms_path}/{realm_name}/authentication/flows/{flow_alias}/executions', execution)

    def create_auth_flow_exec(self, realm_name: str, flow_alias: str, execution: dict):
        return self._post(f'{self.realms_path}/{realm_name}/authentication/flows/{flow_alias}/executions/execution', execution)

    def create_auth_flow_sub_flow(self, realm_name: str, flow_alias: str, sub_flow: dict):
        return self._post(f'{self.realms_path}/{realm_name}/authentication/flows/{flow_alias}/executions/flow', sub_flow)

    def get_users(self, realm):
        users_url = f'{self.realms_path}/{realm}/users'
        response = requests.get(users_url,
                                headers={'Content-Type': 'application/x-www-form-urlencoded',
                                         'Authorization': f'Bearer {self.token}'},
                                verify=constants.current_ssl_verify
                                )
        assert response.status_code == 200
        return response.json()

    def identity_provider_exists(self, realm_name: str, idp_name: str):
        response = requests.get(f'{self.realms_path}/{realm_name}/identity-provider/instances/{idp_name}',
                                headers={'Content-Type': 'application/json',
                                         'Authorization': f'Bearer {self.token}'},
                                verify=constants.current_ssl_verify)
        return response.status_code == 200

    def list_identity_providers(self, realm_name: str):
        return self._get(f'{self.realms_path}/{realm_name}/identity-provider/instances')

    def get_identity_provider(self, realm_name: str, idp_name: str):
        return self._get(f'{self.realms_path}/{realm_name}/identity-provider/instances/{idp_name}')

    def update_identity_provider(self, realm_name: str, idp_name: str, data):
        return self._put(f'{self.realms_path}/{realm_name}/identity-provider/instances/{idp_name}', data)

    def add_identity_provider_mapper(self, realm_name: str, idp_name: str, new_mapper):
        return self._post(f'{self.realms_path}/{realm_name}/identity-provider/instances/{idp_name}/mappers', new_mapper)

    def get_saml_mappers(self, realm_name):
        return self._get(f'{self.realms_path}/{realm_name}/identity-provider/instances/saml/mappers')

    def _post(self, url, data=None):
        return self._data_operation('POST', url, data)

    def _put(self, url, data=None):
        return self._data_operation('PUT', url, data)

    def _data_operation(self, method, url, data=None, retry=False):
        if data:
            data = json.dumps(data)
        response = requests.request(method, url,
                                    headers={'Content-Type': 'application/json',
                                             'Authorization': f'Bearer {self.token}'},
                                    data=data,
                                    verify=constants.current_ssl_verify
                                    )

        if response.status_code == 401 and not retry:
            print("Getting a new token")
            self.token = self.get_token()
            return self._data_operation(method, url, data, True)

        if response.status_code not in [200, 201, 202, 204, 409]:
            print(f'{method} to {url} status {response.status_code}: {response.text}')
            raise Exception()
        if response.status_code == 204:
            return None
        try:
            return response.json()
        except Exception:
            return {}

    def _get(self, url, retry=False):
        response = requests.get(url,
                                headers={'Content-Type': 'application/json',
                                         'Authorization': f'Bearer {self.token}'},
                                verify=constants.current_ssl_verify
                                )

        if response.status_code == 401 and not retry:
            print("Getting a new token")
            self.token = self.get_token()
            return self._get(url, True)

        if not response.status_code == 200:
            print(f'GET to {url} status {response.status_code}: {response.text}')
            raise Exception()
        return response.json()

    def _delete(self, url, retry=False):
        response = requests.delete(url,
                                   headers={'Content-Type': 'application/json',
                                            'Authorization': f'Bearer {self.token}'},
                                   verify=constants.current_ssl_verify
                                   )

        if response.status_code == 401 and not retry:
            print("Getting a new token")
            self.token = self.get_token()
            return self._delete(url, True)


        if not response.status_code == 204:
            print(f'DELETE to {url} status {response.status_code}')
            raise Exception()
