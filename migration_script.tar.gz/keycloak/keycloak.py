import constants
from . import client

BASE_RUNAI_CLIENT_NAME = 'runai'
AUTH_PROTOCOL_OPEN_ID = 'openid-connect'

RUNAI_AUDIENCE_MAPPER = {
    'name': 'Audience',
    'protocol': AUTH_PROTOCOL_OPEN_ID,
    'protocolMapper': 'oidc-audience-mapper',
    'config': {
        'included.client.audience': BASE_RUNAI_CLIENT_NAME,
        'id.token.claim': 'true',
        'access.token.claim': 'true'
    }
}

PASSWORD_POLICY = "digits(1) and " \
                  "lowerCase(1) and " \
                  "upperCase(1) and " \
                  "length(8) and " \
                  "specialChars(1) and " \
                  "forceExpiredPasswordChange(365) and " \
                  "notUsername(undefined) and " \
                  "passwordHistory(10) and " \
                  "notEmail(undefined)"

RUNAI_THEME = "runai-theme"
CLI_CLIENT_ID = 'runai-cli'
GKE_READY_REDIRECT_URL = 'http://localhost:8000/callback'


class Keycloak:
    def __init__(self, tenant_name: str, url: str, password: str):
        print(f'*** creating keycloak instance for {url} and tenant {tenant_name}')
        self.api = client.KeycloakApiClient(url, 'admin', password)
        self.tenant_name = tenant_name

    @staticmethod
    def get_type() -> constants.AuthProvider:
        return constants.AuthProvider.keycloak

    def get_users(self):
        return self.api.get_users(self.tenant_name)

    def obtain_agent_token(self, tenant_name: str, client_id: str, client_name: str) -> (str, str):
        client_secret = self.api.get_client_secret(tenant_name, client_id)
        token = self.api.get_token_of_client(tenant_name, client_name, client_secret["value"])
        return token, client_secret

    def obtain_super_tenant_token(self, client_id: str, client_secret: str) -> str:
        return self.api.get_token_of_client('master', client_id, client_secret)

    # private methods

    def _create_client(self, client_data: dict):
        print(f'going to create client {client_data["clientId"]}')
        self.api.create_client(self.tenant_name, client_data)
        print(f'created client {client_data["clientId"]} successfully')
